### Hexlet tests and linter status:
[![Actions Status](https://github.com/Viktoria-Maltseva/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Viktoria-Maltseva/python-project-49/actions)
### Package installation
<p> To install the project as a package, enter the command "make package-install". <p>
