### Hexlet tests and linter status:
[![Actions Status](https://github.com/Viktoria-Maltseva/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Viktoria-Maltseva/python-project-49/actions)
### Package installation
<p> To install the project as a package, enter the command "make package-install". <p>
### Demonstration of games: brain-even, brain-calc, brain-gcd, brain-progression, brain-prime 
<a href="https://asciinema.org/a/82YftBJincvdefbQrVGl2IoOx" target="_blank"><img src="https://asciinema.org/a/82YftBJincvdefbQrVGl2IoOx.svg" /></a>
<a href="https://asciinema.org/a/UUN7v1lULdign6lGN7t1Og79Z" target="_blank"><img src="https://asciinema.org/a/UUN7v1lULdign6lGN7t1Og79Z.svg" /></a>
<a href="https://asciinema.org/a/OjsdIDM5D01qYYWouQJFskpof" target="_blank"><img src="https://asciinema.org/a/OjsdIDM5D01qYYWouQJFskpof.svg" /></a>
<a href="https://asciinema.org/a/OjsdIDM5D01qYYWouQJFskpof" target="_blank"><img src="https://asciinema.org/a/OjsdIDM5D01qYYWouQJFskpof.svg" /></a>
<a href="https://asciinema.org/a/EC5ZvPoKHzRw82ctESHWlnxgp" target="_blank"><img src="https://asciinema.org/a/EC5ZvPoKHzRw82ctESHWlnxgp.svg" /></a>
<a href="https://asciinema.org/a/JK2SIuJtScej7iPsyfN8GQwyA" target="_blank"><img src="https://asciinema.org/a/JK2SIuJtScej7iPsyfN8GQwyA.svg" /></a>
